# RPI-IoT-Gateway
This Gateway caters to some of the heterogeneous communication technologies used in the Internet of Things (IoT) by providing a mediator which performs Protocol Transformation, Data Format Transformation and basic traffic routing so that "Things" in IoT can communicate with each other. This is still a work in progress.
